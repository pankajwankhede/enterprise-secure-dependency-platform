# Enterprise Secure Dependency Platform

Ready-to-import Gradle multi-module repository for centrally managing approved dependencies across Spring Boot 3.3.x and 3.5.x applications.

All plugins and dependencies are resolved through the internal Nexus group:

`https://nexus.app.abc.com:800/repository/MavenRepositoryGroup/`

## Modules

- `common-security-platform` — shared third-party security constraints.
- `boot-3.3-platform` — Spring Boot 3.3 BOM plus shared constraints.
- `boot-3.5-platform` — Spring Boot 3.5 BOM plus shared constraints.

Java 17 and Java 21 applications use the platform matching their Spring Boot family. Java is configured separately in each consuming repository using the Gradle toolchain.

## First run on Windows

Open PowerShell in the project root:

```powershell
$env:NEXUS_USERNAME="your-user"
$env:NEXUS_PASSWORD="your-password"

.\scripts\run-local.ps1
```

The script downloads Gradle 8.14.3 into `.tools`, builds all platform modules, and publishes them to your local Maven repository.

Local artifacts will be under:

`C:\Users\<username>\.m2\repository\com\syf\platform\`

## Open in IntelliJ IDEA

1. Run `scripts\setup-gradle.ps1` once.
2. Open this repository using **File → Open**.
3. Open **Settings → Build, Execution, Deployment → Build Tools → Gradle**.
4. Select **Specified location** and choose:

   `.tools\gradle-8.14.3`

5. Set **Gradle JVM** to JDK 17 or JDK 21.
6. Reload the Gradle project.

## Alternative credential storage

Create or update this user-level file:

`C:\Users\<username>\.gradle\gradle.properties`

```properties
nexusUsername=your-user
nexusPassword=your-password
```

Never commit credentials to Bitbucket.

## Consume locally from a Spring Boot 3.3.x repository

```gradle
repositories {
    mavenLocal() // local validation only
    maven {
        url = uri("https://nexus.app.abc.com:800/repository/MavenRepositoryGroup/")
        credentials {
            username = System.getenv("NEXUS_USERNAME") ?: findProperty("nexusUsername")
            password = System.getenv("NEXUS_PASSWORD") ?: findProperty("nexusPassword")
        }
    }
}

dependencies {
    implementation platform("com.abc.platform:boot-3.3-platform:1.0.0-SNAPSHOT")
}
```

## Consume locally from a Spring Boot 3.5.x repository

```gradle
dependencies {
    implementation platform("com.abc.platform:boot-3.5-platform:1.0.0-SNAPSHOT")
}
```

After compatibility testing, use `enforcedPlatform(...)` when strict version enforcement is required.

## Publishing to company Nexus

`MavenRepositoryGroup` is configured for downloading. It is normally not a deployment repository.

Before running `publish`, replace these placeholders in `gradle.properties` with hosted Nexus repositories provided by the Nexus team:

```properties
nexusReleaseUrl=https://nexus.app.syfbank.com:8443/repository/<hosted-release-repository>/
nexusSnapshotUrl=https://nexus.app.syfbank.com:8443/repository/<hosted-snapshot-repository>/
```

Then run:

```powershell
.tools\gradle-8.14.3\bin\gradle.bat publish
```

## Where to add versions

Use `common-security-platform/build.gradle` for independent shared libraries such as Bouncy Castle or Apache Commons after validation.

Keep Spring Boot-managed dependency overrides inside the relevant module:

- `boot-3.3-platform/build.gradle`
- `boot-3.5-platform/build.gradle`

Avoid placing one common version of Spring Framework, Tomcat, Jackson, Netty, or Hibernate Validator across different Spring Boot families.
