# Enterprise Nexus Central Dependency Fix

This project creates one Gradle dependency platform/BOM that can be published to Nexus and imported by all Spring Boot repositories.

## Prerequisites

- JDK 17+
- Gradle 8.x installed, or generate the wrapper once with `gradle wrapper`
- Access to Maven Central or your Nexus proxy

## 1. Run locally

```bash
gradle wrapper
./gradlew :dependency-platform:publishToMavenLocal
./gradlew :sample-consumer:clean :sample-consumer:build
./gradlew :sample-consumer:dependencyInsight --dependency bcpkix-jdk18on --configuration runtimeClasspath
```

Windows:

```bat
gradle wrapper
gradlew.bat :dependency-platform:publishToMavenLocal
gradlew.bat :sample-consumer:clean :sample-consumer:build
```

## 2. Configure company Nexus

Edit `gradle.properties`:

```properties
nexusPublicUrl=https://nexus.company.com/repository/maven-public/
nexusReleaseUrl=https://nexus.company.com/repository/maven-releases/
nexusSnapshotUrl=https://nexus.company.com/repository/maven-snapshots/
```

Use environment variables for credentials:

```bash
export NEXUS_USERNAME=my-user
export NEXUS_PASSWORD=my-password
./gradlew :dependency-platform:publish
```

PowerShell:

```powershell
$env:NEXUS_USERNAME="my-user"
$env:NEXUS_PASSWORD="my-password"
.\gradlew.bat :dependency-platform:publish
```

## 3. Minimal change in every existing repository

Add your Nexus repository and one platform line:

```gradle
repositories {
    maven {
        url = uri("https://nexus.company.com/repository/maven-public/")
        credentials {
            username = findProperty("nexusUsername") ?: System.getenv("NEXUS_USERNAME")
            password = findProperty("nexusPassword") ?: System.getenv("NEXUS_PASSWORD")
        }
    }
}

dependencies {
    implementation enforcedPlatform(
        "com.company.platform:secure-dependency-platform:1.0.0"
    )

    implementation "org.springframework.boot:spring-boot-starter-web"
}
```

Remove explicit versions for dependencies controlled by the platform.

Before:

```gradle
implementation "org.bouncycastle:bcprov-jdk18on:1.81"
```

After:

```gradle
implementation "org.bouncycastle:bcprov-jdk18on"
```

## 4. Update one place

All approved versions are in the root `gradle.properties`. Change a version there, publish a new platform release, and update only the platform version in consumer repositories.

Example release:

```properties
platformVersion=1.0.0
bouncyCastleVersion=1.83
```

Then:

```bash
./gradlew :dependency-platform:publish
```

## 5. Important legacy migrations

Do not keep these old artifacts merely by forcing versions:

```gradle
// Remove
implementation "commons-lang:commons-lang:2.6"
implementation "commons-configuration:commons-configuration:1.8"

// Add
implementation "org.apache.commons:commons-lang3"
implementation "org.apache.commons:commons-configuration2"
```

Java imports may need changes:

```java
// Old
import org.apache.commons.lang.StringUtils;

// New
import org.apache.commons.lang3.StringUtils;
```

## 6. Verify each Nexus issue

```bash
./gradlew dependencyInsight --dependency jackson-core --configuration runtimeClasspath
./gradlew dependencyInsight --dependency bcprov-jdk18on --configuration runtimeClasspath
./gradlew dependencyInsight --dependency spring-core --configuration runtimeClasspath
./gradlew dependencyInsight --dependency netty-codec --configuration runtimeClasspath
./gradlew dependencyInsight --dependency tomcat-embed-core --configuration runtimeClasspath
./gradlew dependencyInsight --dependency shiro-core --configuration runtimeClasspath
./gradlew dependencyInsight --dependency xercesImpl --configuration runtimeClasspath
./gradlew dependencyInsight --dependency hibernate-validator --configuration runtimeClasspath
```

## Safety note

The structure is ready to run, but the exact approved version for each Nexus policy violation must match the recommendation shown in your Nexus IQ report and must pass application compatibility tests. Update only `gradle.properties`; do not copy version overrides into every repository.
