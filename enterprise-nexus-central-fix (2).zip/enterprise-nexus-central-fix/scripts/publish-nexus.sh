#!/usr/bin/env bash
set -euo pipefail
: "${NEXUS_USERNAME:?Set NEXUS_USERNAME}"
: "${NEXUS_PASSWORD:?Set NEXUS_PASSWORD}"
./gradlew :dependency-platform:publish
