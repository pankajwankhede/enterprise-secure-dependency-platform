#!/usr/bin/env bash
set -euo pipefail
./gradlew :dependency-platform:publishToMavenLocal
