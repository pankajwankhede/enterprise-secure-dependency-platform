#!/usr/bin/env bash
set -euo pipefail
./gradlew :dependency-platform:publishToMavenLocal
./gradlew :sample-consumer:clean :sample-consumer:build
