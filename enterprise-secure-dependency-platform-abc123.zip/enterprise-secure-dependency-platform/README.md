# Enterprise Secure Dependency Platform

Central Gradle dependency platforms for repositories using different Spring Boot release families.

## Modules

- `common-security-platform`: Boot-independent security constraints such as Bouncy Castle.
- `boot-3.3-platform`: imports the Spring Boot 3.3 BOM plus common constraints.
- `boot-3.5-platform`: imports the Spring Boot 3.5 BOM plus common constraints.
- `sample-consumer-boot33`: Java 17 example.
- `sample-consumer-boot35`: Java 21 example.

## Important design

Spring, Jackson, Netty, Reactor Netty, Logback and HTTP Components are normally managed by the matching Spring Boot BOM. Optional override properties are blank by default. Populate them only with Nexus/security-approved versions after compatibility testing.

A Gradle platform normally publishes POM/module metadata rather than an application JAR. Each platform module also creates a small `*-platform.jar` to support internal pipelines that require a visible JAR. Consumers still need the published POM/module metadata for dependency constraints.

## IntelliJ local setup

1. Open this directory as a Gradle project.
2. Set the Gradle JVM to Java 21.
3. Configure Nexus credentials using environment variables:

```powershell
$env:NEXUS_USERNAME="your-user"
$env:NEXUS_PASSWORD="your-password"
```

Or place credentials in `%USERPROFILE%\.gradle\gradle.properties`:

```properties
nexusUsername=your-user
nexusPassword=your-password
```

Never commit credentials.

## Generate Gradle Wrapper

This ZIP contains wrapper configuration but not the binary wrapper JAR. Using IntelliJ's configured Gradle or your installed Gradle, run once:

```powershell
gradle wrapper --gradle-version 8.14.3
```

Commit `gradlew`, `gradlew.bat`, `gradle/wrapper/gradle-wrapper.jar`, and `gradle/wrapper/gradle-wrapper.properties`.

## Build locally

```powershell
.\gradlew.bat clean build
```

Generated optional JARs appear under:

```text
common-security-platform/build/libs/
boot-3.3-platform/build/libs/
boot-3.5-platform/build/libs/
```

## Publish locally

```powershell
.\gradlew.bat publishToMavenLocal
```

Artifacts appear under:

```text
%USERPROFILE%\.m2\repository\com\abc123\platform\
```

## Publish to company Nexus

First replace these placeholders in `gradle.properties` with hosted Nexus repositories:

```properties
nexusReleaseUrl=...
nexusSnapshotUrl=...
```

Do not use `MavenRepositoryGroup` for publishing; it is the download/group URL.

Then run:

```powershell
.\gradlew.bat clean build publish
```

## Consume from a Boot 3.3 repository

```gradle
dependencies {
    implementation enforcedPlatform("com.abc123.platform:boot-3.3-platform:1.0.0")
    implementation "org.springframework.boot:spring-boot-starter-web"
}
```

## Consume from a Boot 3.5 repository

```gradle
dependencies {
    implementation enforcedPlatform("com.abc123.platform:boot-3.5-platform:1.0.0")
    implementation "org.springframework.boot:spring-boot-starter-webflux"
}
```

## Verify transitive dependency resolution

```powershell
.\gradlew.bat dependencyInsight --dependency jackson-databind --configuration runtimeClasspath
.\gradlew.bat dependencyInsight --dependency netty-codec-http2 --configuration runtimeClasspath
.\gradlew.bat dependencyInsight --dependency bcprov-jdk18on --configuration runtimeClasspath
```

Run these commands from a consuming application repository.

## Legacy dependency warning

A constraint cannot replace a different artifact coordinate. Examples requiring source/dependency migration:

- `commons-lang:commons-lang:2.6` to `org.apache.commons:commons-lang3`
- `commons-configuration:commons-configuration:1.x` to `org.apache.commons:commons-configuration2`
- `io.jsonwebtoken:jjwt:0.9.1` to modern split JJWT modules
