#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
GRADLE="$ROOT/.tools/gradle-8.14.3/bin/gradle"
if [[ ! -x "$GRADLE" ]]; then
  "$ROOT/scripts/setup-gradle.sh"
fi
: "${NEXUS_USERNAME:?Set NEXUS_USERNAME first}"
: "${NEXUS_PASSWORD:?Set NEXUS_PASSWORD first}"
cd "$ROOT"
"$GRADLE" clean build --refresh-dependencies
"$GRADLE" publishToMavenLocal
