$ErrorActionPreference = "Stop"
if (-not $env:NEXUS_USERNAME -or -not $env:NEXUS_PASSWORD) {
    Write-Host "Set NEXUS_USERNAME and NEXUS_PASSWORD first." -ForegroundColor Yellow
    exit 1
}
.\gradlew.bat clean build --refresh-dependencies
.\gradlew.bat publishToMavenLocal
