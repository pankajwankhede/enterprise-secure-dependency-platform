#!/usr/bin/env bash
set -euo pipefail
: "${NEXUS_USERNAME:?Set NEXUS_USERNAME first}"
: "${NEXUS_PASSWORD:?Set NEXUS_PASSWORD first}"
./gradlew clean build --refresh-dependencies
./gradlew publishToMavenLocal
