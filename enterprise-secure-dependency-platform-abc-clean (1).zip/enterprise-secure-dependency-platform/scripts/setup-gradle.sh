#!/usr/bin/env bash
set -euo pipefail
GRADLE_VERSION=8.14.3
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TOOLS="$ROOT/.tools"
ZIP="$TOOLS/gradle-$GRADLE_VERSION-bin.zip"
GRADLE_HOME="$TOOLS/gradle-$GRADLE_VERSION"
mkdir -p "$TOOLS"
if [[ ! -d "$GRADLE_HOME" ]]; then
  curl -fL "https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip" -o "$ZIP"
  unzip -q -o "$ZIP" -d "$TOOLS"
  rm -f "$ZIP"
fi
"$GRADLE_HOME/bin/gradle" --version
