$ErrorActionPreference = "Stop"
$GradleVersion = "8.14.3"
$Root = Split-Path -Parent $PSScriptRoot
$Tools = Join-Path $Root ".tools"
$Zip = Join-Path $Tools "gradle-$GradleVersion-bin.zip"
$GradleHome = Join-Path $Tools "gradle-$GradleVersion"

New-Item -ItemType Directory -Force -Path $Tools | Out-Null

if (-not (Test-Path $GradleHome)) {
    Write-Host "Downloading Gradle $GradleVersion..."
    Invoke-WebRequest `
        -Uri "https://services.gradle.org/distributions/gradle-$GradleVersion-bin.zip" `
        -OutFile $Zip

    Write-Host "Extracting Gradle..."
    Expand-Archive -Path $Zip -DestinationPath $Tools -Force
    Remove-Item $Zip -Force
}

Write-Host "Gradle installed at: $GradleHome" -ForegroundColor Green
Write-Host "In IntelliJ set Gradle distribution to this local path." -ForegroundColor Green
& "$GradleHome\bin\gradle.bat" --version
