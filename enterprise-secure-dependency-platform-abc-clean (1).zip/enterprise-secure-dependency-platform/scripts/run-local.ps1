$ErrorActionPreference = "Stop"
$GradleVersion = "8.14.3"
$Root = Split-Path -Parent $PSScriptRoot
$Gradle = Join-Path $Root ".tools\gradle-$GradleVersion\bin\gradle.bat"

if (-not (Test-Path $Gradle)) {
    & "$PSScriptRoot\setup-gradle.ps1"
}

if (-not $env:NEXUS_USERNAME -or -not $env:NEXUS_PASSWORD) {
    Write-Host "Set NEXUS_USERNAME and NEXUS_PASSWORD first." -ForegroundColor Yellow
    exit 1
}

Push-Location $Root
try {
    & $Gradle clean build --refresh-dependencies
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

    & $Gradle publishToMavenLocal
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
finally {
    Pop-Location
}
